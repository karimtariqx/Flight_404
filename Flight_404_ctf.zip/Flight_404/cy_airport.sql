-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2024 at 03:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- Database: `cy_airport`

-- Create tables
CREATE TABLE IF NOT EXISTS `flights` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(255) NOT NULL,
  `passport` int(255) NOT NULL,
  `BN` varchar(350) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `origin` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `seat` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `files` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `uploads` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Set AUTO_INCREMENT values
ALTER TABLE `flights` MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;
ALTER TABLE `files` MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

-- Flush privileges before creating users
FLUSH PRIVILEGES;

-- Drop existing users if they exist
DROP USER IF EXISTS 'cyctf'@'%';

-- Create user with access from any host
GRANT SELECT, INSERT, UPDATE, DELETE ON `cy_airport`.* TO 'cyctf'@'%' IDENTIFIED BY 'rootpassword';

-- Revoke potentially dangerous file privileges
REVOKE FILE ON *.* FROM 'cyctf'@'%';

-- Ensure privileges are applied
FLUSH PRIVILEGES;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
