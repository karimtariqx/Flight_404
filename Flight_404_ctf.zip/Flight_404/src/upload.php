<?php
session_start();
include("config/db_connect.php");

mysqli_report(MYSQLI_REPORT_OFF);
$success = '';
$error = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    if (isset($_FILES['passport']) && $_FILES['passport']['error'] == UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['passport']['tmp_name'];
        $fileName = $_FILES['passport']['name'];
        $fileSize = $_FILES['passport']['size'];
        $fileType = $_FILES['passport']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $newFileName = uniqid('file', true) . '.' . $fileExtension;
        $uploadFileDir = '3568764387fhggvhgf/uploads/';
        $destPath = $uploadFileDir . $newFileName;


        if (!is_dir($uploadFileDir)) {
            mkdir($uploadFileDir, 0777, true);
        }

     
        $fileContent = file_get_contents($fileTmpPath);

   
        $blacklist = [
            'exec', 'while', 'do', 'php', 'PHP', 'for', 'cmd','chr', 'ord', 'system', 'shell_exec', 'passthru', 'proc_open',
            'popen', 'curl_exec', 'curl_multi_exec', 'parse_ini_file', 'show_source', 'highlight_string', 'eval', 
            'include', 'include_once', 'require', 'require_once', 'file_get_contents', 'file_put_contents', 'readfile', 
            'fopen', 'fwrite', 'fclose', 'fpassthru', 'stream_get_contents', 'unlink', 'rmdir', 'mkdir', 'copy', 
            'read', 'move_uploaded_file', 'getimagesize', 'opendir', 'readdir', 'scandir', 'is_dir', 'is_file', 
            'is_link', 'touch', 'chmod', 'basename', 'dirname', 'pathinfo', 'preg_replace', 'preg_match', 
            'preg_split', 'str_replace', 'json_encode', 'json_decode', 'serialize', 'unserialize'
        ];


        foreach ($blacklist as $blacklistedFunction) {
            if (stripos($fileContent, $blacklistedFunction) !== false) {
          
                unlink($fileTmpPath);
                $error = "Don't try to outsmart me, RCEs are bad.";
                echo "Don't try to outsmart me, RCEs are bad.";
           
                return;
            }
        }

 
        if (move_uploaded_file($fileTmpPath, $destPath)) {
            try {
          
                $stmt = $conn->prepare("INSERT INTO files (uploads) VALUES (:uploads)");
                $stmt->bindParam(':uploads', $destPath);
                if ($stmt->execute()) {
                    $success = "File has been successfully uploaded.";
                   
                } else {
                    $error = "Error saving file path to the database.";
                  
                }
            } catch (PDOException $e) {
                error_log("Database Error: " . $e->getMessage());
                $error = "An error occurred while saving the file. Please try again later.";
               
            }
        } else {
            $error = "There was an error moving the uploaded file.";
           
        }
    } else {
        $error = "No file uploaded or there was an upload error.";
       
    }
}
?>





<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departures</title>
    <link rel="stylesheet" href="Styles/arrivals.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <a href="index.html" class="logo">CY-Airport</a>
            <ul class="x">
                
            </ul>
        </div>
        <div class="content">
            <h1 class="text">Provide a Picture of your passport please 🛫</h1>
            <h4>Only PNG files allowed</h4>
            <?php 
              
                echo $success; 
                echo $error;
            ?>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="file" name="passport" required>
                <button type="submit">Upload</button>
            </form>
        </div>
    </div>
</body>
</html>
