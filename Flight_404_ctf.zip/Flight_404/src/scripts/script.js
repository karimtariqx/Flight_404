function E(str, shift) {
    return str.replace(/[a-zA-Z]/g, function(c) {
        let code = c.charCodeAt(0);
        if ((code >= 65) && (code <= 90)) { 
            return String.fromCharCode(((code - 65 + shift) % 26) + 65);
        } else if ((code >= 97) && (code <= 122)) { 
            return String.fromCharCode(((code - 97 + shift) % 26) + 97);
        }
        return c;
    });
}


function generateBookingNumber() {
    return  (Math.floor(10000000 + Math.random() * 90000000));
}


function eS(event) {
    event.preventDefault(); 

    
    let formData = {
        name: document.getElementsByName('name')[0].value,
        passport: document.getElementsByName('passport')[0].value,
        origin: document.getElementsByName('origin')[0].value,
        destination: document.getElementsByName('destination')[0].value,
        BN: generateBookingNumber()
    };

    
    let combinedData = Object.keys(formData).map(key => `${key}=${formData[key]}`).join('|');

    
    let e = E(combinedData, 3);

    
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'generate.php';
    
    
    let input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'e';
    input.value = e;
    form.appendChild(input);
    
    document.body.appendChild(form);
    form.submit(); 
}