<?php
session_start();
include('config/db_connect.php'); 

$error = '';
if (!isset($_SESSION['booking'])) {
    die('No booking number provided.'); 
}

$booking = $_SESSION['booking'];


if (preg_match('/(union|and|or|;|sleep)/i', $booking)) { 
    exit('Potentially malicious input detected.'); 
}

mysqli_report(MYSQLI_REPORT_OFF); 

$query = "SELECT seat, CONCAT('Flight', id, '.seat', seat) AS qrtext 
          FROM flights 
          WHERE (BN = '$booking')";


if (strpos(strtolower($query), 'load_file') !== false) {
    die('LOAD_FILE function is not allowed.');
}

try {
    $result = mysqli_query($mysqli_conn, $query);
    
    if ($result) {
        $qrtext = "";
        while ($row = mysqli_fetch_assoc($result)) {
            if (isset($row['qrtext'])) {
                $qrtext = $row['qrtext'];
            }
            
           
            if (isset($row['flag'])) {
                $qrtext .= " | Flag: " . htmlspecialchars($row['flag'], ENT_QUOTES, 'UTF-8'); 
            }
        }

      
        include('phpqrcode/qrlib.php');
        $path = 'images/';
        $qrcode = $path . time() . ".png";

      
        QRcode::png($qrtext, $qrcode, 'H', 4, 4);
    } else {
        
        $error =  'An error occurred while fetching flight details. Please try again later.';

     
    }
} catch (mysqli_sql_exception $e) {
 
    error_log('SQL Exception: ' . $e->getMessage());
    $error = 'An error occurred while fetching flight details. Please try again later.';
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR CODE</title>
    <link rel="stylesheet" href="Styles/check.css">
</head>
<body>
<div class="banner">
    <div class="welcome-container">
        <h1 class="welcome-text">Welcome to CY-Airport</h1>
    </div>
    <div class="form-container">
        <form action="check.php" method="post" class="login-form">
            <h2>TICKET</h2>
            <?php 
              
                echo isset($qrcode) ? "<img src='" . $qrcode . "'>" : ''; 
                echo $error;
            ?>
        </form>
    </div>
</div>
</body>
</html>


