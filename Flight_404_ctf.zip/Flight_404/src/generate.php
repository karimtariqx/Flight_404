<?php
session_start();
include('config/db_connect.php');

mysqli_report(MYSQLI_REPORT_OFF);
$error = '';

function caesarDecrypt($str, $shift) {
    $decrypted = '';
    for ($i = 0; $i < strlen($str); $i++) {
        $c = $str[$i];
        if (ctype_alpha($c)) {
            $code = ord($c);
            if ($code >= 65 && $code <= 90) { 
                $c = chr((($code - 65 - $shift + 26) % 26) + 65);
            } elseif ($code >= 97 && $code <= 122) { 
                $c = chr((($code - 97 - $shift + 26) % 26) + 97);
            }
        }
        $decrypted .= $c;
    }
    return $decrypted;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    if (!isset($_POST['e']) || empty($_POST['e'])) {
        die('Empty or missing data!');
    }

    $decryptedData = caesarDecrypt($_POST['e'], 3);

    parse_str(str_replace('|', '&', $decryptedData), $formData);

    $name = filter_var(trim($formData['name']), FILTER_SANITIZE_STRING);
    $passport = filter_var(trim($formData['passport']), FILTER_SANITIZE_STRING);
    $origin = filter_var(trim($formData['origin']), FILTER_SANITIZE_STRING);
    $destination = filter_var(trim($formData['destination']), FILTER_SANITIZE_STRING);
    $booking_number = $formData['BN'];

    if (!preg_match('/^[A-Za-z\s]+$/', $name)) {
        die('Invalid name format.');
    }
    if (!preg_match('/^[A-Z0-9-]+$/', $passport)) {
        die('Invalid passport format.');
    }
    if (!preg_match('/^[A-Za-z\s]+$/', $origin) || !preg_match('/^[A-Za-z\s]+$/', $destination)) {
        die('Invalid origin or destination format.');
    }

    $_SESSION['booking'] = $booking_number;

    $booking_number = filter_var(trim($formData['BN']), FILTER_SANITIZE_STRING);

    $id = substr(uniqid(), 0, 16); 
    $date = date('Y-m-d H:i:s');
    $seat = rand(1, 100);

    try {
        $query = "INSERT INTO flights (name, passport, BN, origin, destination, date, seat) VALUES (:name, :passport, :BN, :origin, :destination, :date, :seat)";
        $stmt = $conn->prepare($query);
        
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':passport', $passport);
        $stmt->bindParam(':BN', $booking_number);
        $stmt->bindParam(':origin', $origin);
        $stmt->bindParam(':destination', $destination);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':seat', $seat);

        if ($stmt->execute()) {
            $_SESSION['id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['passport'] = $passport;
            $_SESSION['date'] = $date;
            $_SESSION['origin'] = $origin;
            $_SESSION['destination'] = $destination;
            $_SESSION['seat'] = $seat;
            
            header('Location: confirmation.php');
            exit;
        } else {
            throw new Exception("Failed to generate ticket.");
        }
    } catch (Exception $e) {
        $error = "An error occurred while processing your request. Please try again later.";
        error_log("Error: " . $e->getMessage());
    }
}





//name=test&passport=2353453&origin=test&destination=test&BN=56564459

?>





<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Ticket</title>
    <link rel="stylesheet" href="Styles/check.css">
    <script src="scripts/script.js"></script>
</head>
<body>
<div class="banner">
    <div class="welcome-container">
        <h1 class="welcome-text">Welcome to CY-Airport</h1>
    </div>
    <div class="form-container">
        <form action="generate.php" method="post" class="login-form" onsubmit="eS(event);">
            <h2>Generate Ticket</h2>
            <label for="name">Name:</label>
            <br>
            <input type="text" name="name" placeholder="Enter your name" required>
            <br><br>
            <label for="passport">Passport Number:</label>
            <br>
            <input type="text" name="passport" placeholder="xxxxxxxx" required>
            <br><br>
            <label for="origin">Origin:</label>
            <br>
            <input type="text" name="origin" placeholder="Enter origin" required>
            <br><br>
            <label for="destination">Destination:</label>
            <br>
            <input type="text" name="destination" placeholder="Enter destination" required>
            <br><br>
            <input type="submit" value="Generate">
            <?php echo $error; ?>
        </form>
    </div>
</div>
</body>
</html>

