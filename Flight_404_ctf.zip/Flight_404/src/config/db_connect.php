<?php
mysqli_report(MYSQLI_REPORT_OFF);


$servername = 'db';  
$username = 'cyctf';  
$password = 'rootpassword';      
$dbname = 'cy_airport'; 

// PDO connection for certain pages
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo 'error, try again later'; 
}

// MySQLi Connection for vulnerablle page
$mysqli_conn = @mysqli_connect($servername, $username, $password, $dbname);


if (!$mysqli_conn) {
    die("error, try again later");
}
?>
