<?php
session_start();

include('config/db_connect.php'); 

$id = $_SESSION['id'] ?? null;
$name = $_SESSION['name'] ?? null;
$passport = $_SESSION['passport'] ?? null; 
$date = $_SESSION['date'] ?? null;
$origin = $_SESSION['origin'] ?? null;
$destination = $_SESSION['destination'] ?? null;
$seat = $_SESSION['seat'] ?? null;

mysqli_report(MYSQLI_REPORT_OFF);
$error = '';

try {
    $stmt = $conn->prepare("SELECT * FROM flights WHERE passport = :passport");
    $stmt->bindParam(':passport', $passport);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $flightData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $id = htmlspecialchars($flightData['id'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($flightData['name'], ENT_QUOTES, 'UTF-8');
        $passport = htmlspecialchars($flightData['passport'], ENT_QUOTES, 'UTF-8');
        $date = htmlspecialchars($flightData['date'], ENT_QUOTES, 'UTF-8');
        $origin = htmlspecialchars($flightData['origin'], ENT_QUOTES, 'UTF-8');
        $destination = htmlspecialchars($flightData['destination'], ENT_QUOTES, 'UTF-8');
        $seat = htmlspecialchars($flightData['seat'], ENT_QUOTES, 'UTF-8');
    } else {
        $error = "No flight data found for this passport.";
    }
} catch (PDOException $e) {
    $error = "An error occurred while fetching flight data. Please try again later.";
    error_log("Error fetching flight data: " . $e->getMessage());
}


if ($error) {
    echo '<p>' . htmlspecialchars($error) . '</p>';
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Flights</title>
    <link rel="stylesheet" href="Styles/arrivals.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <a href="index.html" class="logo">CY-Airport</a>
            <ul class="x">
                
            </ul>
        </div>
        <div class="content">
            <h1 class="text">Your Flights 🛫</h1>
            <br>
            <table class="classes-table">
                <thead>
                    <tr>
                        <th>Flight ID</th>
                        <th>Name</th>
                        <th>Passport Number</th>
                        <th>Date & Time</th>
                        <th>Origin</th>
                        <th>Destination</th>
                        <th>Seat Number</th>
                        <th>Ticket QR-Code</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $name; ?></td>
                        <td><?php echo $passport; ?></td>
                        <td><?php echo $date; ?></td>
                        <td><?php echo $origin; ?></td>
                        <td><?php echo $destination; ?></td>
                        <td><?php echo $seat; ?></td>
                        <td><a href="qrcode.php"><button id="qrcode" name="qr" value="submit">Get Ticket QR-Code<span></span></button></a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
