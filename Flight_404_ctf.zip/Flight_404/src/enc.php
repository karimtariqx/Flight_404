<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caesar Cipher Encryptor</title>
</head>
<body>
    <h2>Encrypt Data</h2>

   
    <form method="POST" action="">
        <label for="dataInput">Enter Data</label><br>
        <input type="text" name="data_input" id="dataInput" required>
        <button type="submit" name="encrypt">Encrypt</button>
    </form>

    <?php

    function caesarEncrypt($str, $shift) {
        $encrypted = '';
        for ($i = 0; $i < strlen($str); $i++) {
            $c = $str[$i];
            if (ctype_alpha($c)) {
                $code = ord($c);
                if ($code >= 65 && $code <= 90) { 
                    $c = chr((($code - 65 + $shift) % 26) + 65);
                } elseif ($code >= 97 && $code <= 122) { 
                    $c = chr((($code - 97 + $shift) % 26) + 97);
                }
            }
            $encrypted .= $c;
        }
        return $encrypted;
    }

    
    if (isset($_POST['encrypt']) && !empty($_POST['data_input'])) {
        $dataInput = $_POST['data_input'];


        parse_str($dataInput, $formData);
        
       
        $encryptedPairs = [];
        foreach ($formData as $key => $value) {
            $encryptedKey = caesarEncrypt($key, 3); 
            $encryptedValue = caesarEncrypt($value, 3); 
            $encryptedPairs[] = $encryptedKey . '=' . $encryptedValue; 
        }

      
        $output = implode('|', $encryptedPairs);
        
        
        $encodedOutput = urlencode($output);

        echo "<h3>Encrypted Data:</h3>";
        echo "<pre>$encodedOutput</pre>";
    }
    ?>
</body>
</html>
