#!/bin/bash

# Write the flag to /flag.txt if it exists in the environment
if [ -n "$FLAG" ]; then
  echo "$FLAG" > /flag.txt
  echo "Flag written to /flag.txt"
else
  echo "FLAG environment variable not set!"
fi

# Start Apache server
apache2-foreground
